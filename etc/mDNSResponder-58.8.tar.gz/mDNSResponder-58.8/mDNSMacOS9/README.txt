This directory contains support files for running mDNS on Mac OS 9
(and Carbon).

mDNS.mcp is a CodeWarrior 8 project file.

mDNSMacOS9.c and mDNSMacOS9.h are the Platform Support files that go below
mDNS Core.

"Mac OS Test Responder.c" and "Mac OS Test Searcher.c" build an example
mDNS Responder and Searcher, respectively.